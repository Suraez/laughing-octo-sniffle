def handler(event, context=None):
    return {"message": "The End"}
    