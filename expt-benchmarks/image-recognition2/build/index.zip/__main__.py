import handler

def main(params):
    return handler.handler(params)