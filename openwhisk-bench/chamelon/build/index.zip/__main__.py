import handler

def main(dict):
    return handler.handler(dict, None)
